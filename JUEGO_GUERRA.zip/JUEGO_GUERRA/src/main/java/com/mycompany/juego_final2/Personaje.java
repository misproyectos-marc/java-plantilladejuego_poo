/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juego_final2;

import java.awt.Color;
import java.util.LinkedList;
import java.util.function.Consumer;

/**
 *
 * @author marcr
 */
public abstract class Personaje extends Personajes{
    
    //id de la pieza
    protected int id;
    //id del jugador
    protected int jugador;
    //posicion actual
    protected int posicionhorizontal;
    protected int posicionvertical;
    //arquero, guerrero, mago, cientifico
    protected String tipo;
    //color de la pieza
    protected Color color;
   
    
    //constructor = agregar id, jugador, posicion, tipo
    public Personaje(int id, int jugador, int posicionhorizontal, int posicionvertical, String tipo, Color color){
        
    this.id = id;
    this.jugador = jugador;
    this.posicionhorizontal = posicionhorizontal;
    this.posicionvertical = posicionvertical;
    this.tipo = tipo;
    this.color = color;
    }
    
    //getters y setters variables

    public int getPosicionhorizontal() {
        return posicionhorizontal;
    }

    public int getPosicionvertical() {
        return posicionvertical;
    }
    public Color getColor() {
        return color;
    }

    public int getJugador() {
        return jugador;
    }


    public int getId() {
        return id;
    }
    
    
    public abstract String toString();
    

    public abstract int getDistancia_ideal();

    
   //metodo para mover "recuerda que el tablero es 100*20"
   public abstract void mover(int tipomover);
   //EXPRESSION LAMBDA QUE REALIZARA EL MOVIMIENTO...
   Lambda_mover moverse = (int tipomover, int posicionhorizontal, int posicionvertical) -> {
   //tipomover ===== derecha = 0 - izquierda = 1 - arriva = 3 - abajo = 2
   if (tipomover == 0){
       if ((posicionhorizontal+1) <= 99) {
           //mover derecha
           this.posicionhorizontal++;
       }
   }
   if (tipomover == 1){
       if ((posicionhorizontal-1) >= 0){
           //mover izquierda
           this.posicionhorizontal--;
       }
   }
   if (tipomover == 2){
       if ((posicionvertical+1) <= 19) {
           //mover abajo
           this.posicionvertical++;

       }
   }
   if (tipomover == 3){
       if ((posicionvertical-1) >= 0) {
           //mover arriva
           this.posicionvertical--;
       }
   }
    
   };
}

class Arquero extends Personaje{
    protected final int distancia_ideal = 6; //poner un número de distància ideal
                                    //como más cerca al número mejor
    protected final int movimiento_maximo = 2;//poner un numero maximo de movimientos
    
    private int vida;
    private int defensa;
    private int ataque;

    public Arquero(int id, int jugador, int posicionhorizontal, int posicionvertical, String tipo, Color color){
        
    super(id, jugador, posicionhorizontal, posicionvertical, tipo, color);
    this.vida = 3;
    this.defensa = 7;
    this.ataque = 2;    
    }
    //getters
    @Override
    public int getDistancia_ideal() {
        return distancia_ideal;
    }

    //metodos

    @Override
    public void mover(int tipomover){
    //tipomover ===== derecha = 0 - izquierda = 1 - arriva = 2 - abajo = 3
    moverse.movimiento(tipomover, this.posicionhorizontal, this.posicionvertical);
    }
    
    @Override 
    public String toString(){
        String cadena = "ARQUERO--- \n:" + this.tipo + "\n id: " + this.id + "\n vida: " + this.vida + "\n defensa: " + this.defensa + "\n ataque: " + this.ataque;
    return cadena;
    }

}
class Guerrero extends Personaje{
    protected final int distancia_ideal = 2; //poner un número de distància ideal
                                    //como más cerca al número mejor
    protected final int movimiento_maximo = 4;//poner un numero màximo de movimientos

    private int vida;
    private int defensa;
    private int ataque;
    
    public Guerrero(int id, int jugador, int posicionhorizontal, int posicionvertical, String tipo, Color color){
    super(id, jugador, posicionhorizontal, posicionvertical, tipo, color);
    
    this.vida = 4;
    this.defensa = 11;
    this.ataque = 5;
    }
    //getters
    @Override
    public int getDistancia_ideal() {
        return distancia_ideal;
    }
    
    //metodos
    @Override
    public void mover(int tipomover){
    moverse.movimiento(tipomover, this.posicionhorizontal, this.posicionvertical);
    }
    
    @Override 
    public String toString(){
        String cadena = "guerrero--- \n:" + this.tipo + "\n id: " + this.id + "\n vida: " + this.vida + "\n defensa: " + this.defensa + "\n ataque: " + this.ataque;
    return cadena;
    }

}
class Mago extends Personaje{
    protected final int distancia_ideal = 20; //poner un número de distància ideal
                                    //como más cerca al número mejor
    protected final int movimiento_maximo = 5;//poner un numero màximo de movimientos

    private int vida;
    private int defensa;
    private int ataque;
    
    public Mago(int id, int jugador, int posicionhorizontal, int posicionvertical, String tipo, Color color){
    super(id, jugador, posicionhorizontal, posicionvertical, tipo, color);
    this.vida = 3;
    this.defensa = 10;
    this.ataque = 1;
    }
    
    //getters
    @Override
    public int getDistancia_ideal() {
        return distancia_ideal;
    }
    //metodos
    @Override
    public void mover(int tipomover){
    moverse.movimiento(tipomover, this.posicionhorizontal, this.posicionvertical);
    }
    
   @Override
    public String toString() {
        String cadena = "MAGO--- \n:" + this.tipo + "\n id: " + this.id + "\n vida: " + this.vida + "\n defensa: " + this.defensa + "\n ataque: " + this.ataque;
        return cadena;
    }

}
class Ingeniero extends Personaje{
    protected final int movimiento_maximo = 5;//poner un numero màximo de movimientos
    protected final int distancia_ideal = movimiento_maximo; //Ingeniero no tiene distancia ideal

    private int vida;
    //los ingenieros tardan en producir "tiempo carga"
    //el tiempodurado es el tiempo que lleva este investigando...
    private int tiempocarga;
    private int tiempodurado;
    public Ingeniero(int id, int jugador, int posicionhorizontal, int posicionvertical, String tipo, Color color){
        
    super(id, jugador, posicionhorizontal, posicionvertical, tipo, color);
    this.vida = 10;
    }
    
    //getters
    @Override
    public int getDistancia_ideal() {
        return distancia_ideal;
    }
    //metodos
    @Override
    public void mover(int tipomover){
    moverse.movimiento(tipomover, this.posicionhorizontal, this.posicionvertical);

    }
    
    
    @Override 
    public String toString(){
        String cadena ="INGENIERO--- \n" + this.tipo + "\n id: " + this.id + "\n vida: " + this.vida + "\n tiempo investigado: " + tiempodurado + "/" + tiempocarga;
    return cadena;  //idea = investigar todos los inventos que quieras y usarlos cuando quieras cada uno
    }


}