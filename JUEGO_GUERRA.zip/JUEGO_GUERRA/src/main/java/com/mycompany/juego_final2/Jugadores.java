/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juego_final2;

import java.awt.Color;

/**
 *
 * @author marcr
 */
public class Jugadores {
    private String habilidad; //se crean con el científico, hay 3 habilidades
    private int numerojugador;
    private int horizontalinicial; //segun el personaje es 0 "izquierda" o 20 "derecha"
    
    private Color colorarquero;
    private Color colorguerrero;
    private Color colorIngeniero;
    private Color colorMago;
    
    //constructor paràmetros= numerojugador, horizontalinicial, "habilidad inicial = nula"
    public Jugadores(int numerojugador){ //pasar jugador 0 o 1
    this.habilidad = "nula";
    this.numerojugador = numerojugador;
    
    //si el numerojugador es igual a 0 = horizontalinicial = 0
    //si el numerojugador es igual a 1 = horizontalinicial = 20
    if (this.numerojugador == 0){
        this.horizontalinicial = 0;
        
        //color de las piezas
        this.colorarquero = Color.BLUE;
        this.colorguerrero = Color.yellow;
        this.colorMago = Color.red;
        this.colorIngeniero = Color.pink;
        
    }
    if (this.numerojugador == 1){
        this.horizontalinicial = 99;
        
        //color de las piezas
        this.colorarquero = Color.orange;
        this.colorguerrero = Color.black;
        this.colorMago = Color.GREEN;
        this.colorIngeniero = Color.MAGENTA;
    }
    
    }
    

    
    //Pasar por parametros la lista donde se guardan los personajes
    public Personajes crear_personajes_iniciales(Personajes personajes){
        //inicialmente creare estos personajes igual para cada equipo:

        /*
        arquero1 = 0 * 0 arquero2 = 0*20
        guerrero1 = 0*3guerrero2 = 0*17guerrero3 = 0*13guerrero4 = 0*7           
        mago = 0*10
        ingeniero1 = 0*5 ingeniero2 = 0*15
        */
        //crear arqueros
        personajes.crear_arquero(this.numerojugador, this.horizontalinicial, 0, this.colorarquero);
        personajes.crear_arquero(this.numerojugador, this.horizontalinicial, 19, this.colorarquero);
        //crear guerreros
        personajes.crear_guerrero(this.numerojugador, this.horizontalinicial, 3, this.colorguerrero);

        personajes.crear_guerrero(this.numerojugador, this.horizontalinicial, 17, this.colorguerrero);
        personajes.crear_guerrero(this.numerojugador, this.horizontalinicial, 13, this.colorguerrero);
        personajes.crear_guerrero(this.numerojugador, this.horizontalinicial, 7, this.colorguerrero);
        //crear mago
        personajes.crear_mago(this.numerojugador, this.horizontalinicial, 10, this.colorMago);
        //crear ingeniero
        personajes.crear_ingeniero(this.numerojugador, this.horizontalinicial, 5, this.colorIngeniero);
        personajes.crear_ingeniero(this.numerojugador, this.horizontalinicial, 15, this.colorIngeniero);

        
        return personajes;
    }   

    
    
}
