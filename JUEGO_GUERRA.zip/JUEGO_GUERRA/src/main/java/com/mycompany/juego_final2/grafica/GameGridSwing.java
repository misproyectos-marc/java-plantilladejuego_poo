/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juego_final2.grafica;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author marcr
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class GameGridSwing extends JFrame {

    private final int NUM_ROWS = 20;
    private final int NUM_COLS = 100;
    private static final int CELL_SIZE = 20;

    private JPanel[][] cells;
    
    //paneles de salida:
    private JPanel outputPanelLeft;
    private JPanel outputPanelRight;
    //getters
    public int getNUM_ROWS() {
        return NUM_ROWS;
    }

    public int getNUM_COLS() {
        return NUM_COLS;
    }
    
    //CREAR PANELES Y AGREGARLOS MAS TARDE...
    public GameGridSwing(){
        
        //CREAR PANELES DE SALIDA COMO ATRIBUTO "CREARLOS EN EL CONSTRUCTOR"
        setTitle("Game Grid");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Inicializar paneles de salida
        outputPanelLeft = new JPanel();
        outputPanelLeft.setPreferredSize(new Dimension(200, 100));
        outputPanelLeft.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        outputPanelRight = new JPanel();
        outputPanelRight.setPreferredSize(new Dimension(200, 100));
        outputPanelRight.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        outputPanelLeft.setLayout(new BorderLayout());
        outputPanelRight.setLayout(new BorderLayout());
    }
    //pasar transformador a la lista "setter"
    Transformador transformador;
    public void pasar_transformador(Transformador transformador){
    this.transformador = transformador;
    }
    //iniciar grafica
    public void init() {
        setTitle("Game Grid");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Crear el panel para la cuadrícula
        JPanel gridPanel = new JPanel(new GridLayout(NUM_ROWS, NUM_COLS));
        gridPanel.setBackground(Color.WHITE);

        // Inicializar la matriz de casillas
        cells = new JPanel[NUM_ROWS][NUM_COLS];

        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_COLS; col++) {
                JPanel cell = new JPanel();
                cell.setPreferredSize(new Dimension(CELL_SIZE, CELL_SIZE));
                cell.setBackground(Color.WHITE);
                cell.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                gridPanel.add(cell);

                // Agregar la casilla a la matriz
                cells[row][col] = cell;
            }
        }

        // Crear el panel para el área en blanco
        JPanel blankPanel = new JPanel();
        blankPanel.setBackground(Color.WHITE);

// Crear panel para los botones
        JPanel buttonPanel = new JPanel();
        JButton button1 = new JButton("Atacar");
        JButton button2 = new JButton("Terminar-Realizar");
        JButton button3 = new JButton("Terminar-Realizar");
        JButton button4 = new JButton("Atacar");


        buttonPanel.add(button1);
        buttonPanel.add(button2);
        buttonPanel.add(button3);
        buttonPanel.add(button4);

//crear listas desplegables
        JPanel comboBoxPanel = new JPanel(new BorderLayout());
        JComboBox<String> comboBox1 = new JComboBox<>(new String[]{"arquero id:0", "arquero id:1", "guerrero id:2", "guerrero id:3", "guerrero id:4", "guerrero id:5", "mago id:6", "ingeniero id:7", "ingeniero id:8"});
        JComboBox<String> comboBox2 = new JComboBox<>(new String[]{"nula", "torreta", "fàbrica", "muro"});
        JComboBox<String> comboBox3 = new JComboBox<>(new String[]{"arquero id:9", "arquero id:10", "guerrero id:11", "guerrero id:12", "guerrero id:13", "guerrero id:14", "mago id:15", "ingeniero id:16", "ingeniero id:17"});
        JComboBox<String> comboBox4 = new JComboBox<>(new String[]{"nula", "torreta", "fàbrica", "muro"});
        
        // Panel para las primeras dos listas desplegables
        JPanel comboBoxLeftPanel = new JPanel();
        comboBoxLeftPanel.add(comboBox1);
        comboBoxLeftPanel.add(comboBox2);
        
        // Panel para las últimas dos listas desplegables
        JPanel comboBoxRightPanel = new JPanel();
        comboBoxRightPanel.add(comboBox3);
        comboBoxRightPanel.add(comboBox4);
        
        comboBoxPanel.add(comboBoxLeftPanel, BorderLayout.WEST);
        comboBoxPanel.add(comboBoxRightPanel, BorderLayout.EAST);

// Agregar todos los tipos de paneles al JFrame usando BorderLayout
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(gridPanel, BorderLayout.CENTER);
        getContentPane().add(blankPanel, BorderLayout.SOUTH);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        getContentPane().add(comboBoxPanel, BorderLayout.NORTH);
        getContentPane().add(outputPanelLeft, BorderLayout.WEST);
        getContentPane().add(outputPanelRight, BorderLayout.EAST);

        // Ajustar el tamaño del JFrame para mostrar ambos paneles
        int frameHeight = NUM_ROWS * CELL_SIZE + CELL_SIZE + 50; // 50 es un espacio para los botones
        int frameWidth = NUM_COLS * CELL_SIZE;
        setSize(frameWidth, frameHeight);

        setVisible(true);
        
        
        
        
//Crear Action listener de los objetos
//1.ACTION LISTENER SELECCIONAR PIEZA
         // ActionListener para personajes jugador 0
comboBox1.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String selectedValue = (String) comboBox1.getSelectedItem();
        //borrar colores "white" ---reset
        transformador.pintar_todo_blanco(NUM_ROWS, NUM_COLS);
        //pintar las posiciones de los personajes de nuevo
        transformador.pintar_posiciones_personajes();
        //pintar casillas de alcance del personaje seleccionado
        transformador.pintar_jugador_seleccionado(selectedValue);

        
        gridPanel.requestFocusInWindow();

        gridPanel.requestFocus();
    }
});

// ActionListener para personajes jugador 1
comboBox3.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String selectedValue = (String) comboBox3.getSelectedItem();
        
        //borrar colores "white" ---reset
        transformador.pintar_todo_blanco(NUM_ROWS, NUM_COLS);
        //pintar las posiciones de los personajes de nuevo
        transformador.pintar_posiciones_personajes();
        //pintar casillas de alcance del personaje seleccionado
        transformador.pintar_jugador_seleccionado(selectedValue);

        gridPanel.requestFocusInWindow();

        gridPanel.requestFocus();
    }
});
//2.ACTION LISTENER APRETAR BOTON DERECHA IZQUIERDA ARRIVA ABAJO
   //tipomover ===== derecha = 0 - izquierda = 1 - arriva = 3 - abajo = 2

        gridPanel.addKeyListener(new KeyListener() {
    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        switch (keyCode) {
            case KeyEvent.VK_UP:
                //System.out.println("Tecla Arriba presionada");
                transformador.mover(3);
                  
                break;
            case KeyEvent.VK_DOWN:
                //System.out.println("Tecla Abajo presionada");
                transformador.mover(2);
               
                break;
            case KeyEvent.VK_LEFT:
                //System.out.println("Tecla Izquierda presionada");
                transformador.mover(1);
           
                break;
            case KeyEvent.VK_RIGHT:
                //System.out.println("Tecla Derecha presionada");
                transformador.mover(0);
                          
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}
});

// Establecer el enfoque en el gridPanel para que pueda recibir eventos de teclado
gridPanel.setFocusable(true);
gridPanel.requestFocusInWindow();


    }
   
    

    // Método para pintar una casilla específica
    public void paintCell(int row, int col, Color color) {
        cells[row][col].setBackground(color);
    }
    //saver el color de la celda
    public boolean isCellColor(int row, int col, Color color) {
    return cells[row][col].getBackground().equals(color);
    }
    
//metodos para cambiar el texto de los paneles
    public void cambiartextoizquierdo(String texto) {
   //     String texto = objeto.toString();
    JTextArea textArea = new JTextArea(texto);
    JScrollPane scrollPane = new JScrollPane(textArea);
    scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS); // Asegurar que la barra vertical esté siempre visible

    outputPanelLeft.removeAll();
    outputPanelLeft.add(scrollPane, BorderLayout.CENTER); 
    outputPanelLeft.revalidate();
    outputPanelLeft.repaint();
    }

    public void cambiartextoderecho(String texto) {
//    String texto = objeto.toString();
    JTextArea textArea = new JTextArea(texto);
    JScrollPane scrollPane = new JScrollPane(textArea);
    scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS); // Asegurar que la barra vertical esté siempre visible

    outputPanelRight.removeAll();
    outputPanelRight.add(scrollPane, BorderLayout.CENTER);
    outputPanelRight.revalidate();
    outputPanelRight.repaint();

    }

}