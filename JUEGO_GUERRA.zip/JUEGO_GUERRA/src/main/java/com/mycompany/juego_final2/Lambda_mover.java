/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.juego_final2;

/**
 *
 * @author marcr
 */
public interface Lambda_mover {
    void movimiento(int tipomover, int posicionhorizontal, int posicionvertical);
}
