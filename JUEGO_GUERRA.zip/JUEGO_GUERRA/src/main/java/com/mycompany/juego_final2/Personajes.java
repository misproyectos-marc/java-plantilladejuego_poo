/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juego_final2;

import java.awt.Color;
import java.util.LinkedList;

/**
 *
 * @author marcr
 */
public class Personajes{
    
    LinkedList<Personaje> personajes = new LinkedList<>();
    private int id = -1;  //el max en total son 18
    private int id_pieza; //pieza seleccionada
    
    public Personajes(){
    this.personajes = personajes;
    this.id = id;
    this.id_pieza = id_pieza;
    }
    
    //getter = retornar lista personajes
    public LinkedList<Personaje> getPersonajes() {
        
        return personajes;
    }
    //retornar un personaje con su id
    public Personaje getpersonaje(int id){
    
    return personajes.get(id);
    }

    public int getId_pieza() {
        return id_pieza;
    }

    public void setId_pieza(int id_pieza) {
        this.id_pieza = id_pieza;
    }
    
    
    //metodo para crear un arquero
    //pasar id, jugador"equipo", posicion inicial
    public void crear_arquero(int jugador, int posicionhorizontal, int posicionvertical, Color color){
    this.id++; //sumar id
    Arquero arquero = new Arquero(id, jugador, posicionhorizontal, posicionvertical, "Arquero", color);


    personajes.add(arquero);
    //personajes.get(id).posicionhorizontal = 0;
    //personajes.get(0).mover();
    
    }
    //metodo para crear un guerrero
    //pasar id, jugador"equipo", posicion inicial
    public void crear_guerrero(int jugador, int posicionhorizontal, int posicionvertical, Color color){
    this.id++; //sumar id

    Guerrero guerrero = new Guerrero(id, jugador, posicionhorizontal, posicionvertical, "Guerrero", color);

    personajes.add(guerrero);
    //personajes.get(id).posicionhorizontal = 0;
    //personajes.get(id).posicionvertical = 0;
    
    }
    //metodo para crear un mago
    //pasar id, jugador"equipo", posicion inicial
    public void crear_mago(int jugador, int posicionhorizontal, int posicionvertical, Color color){
    this.id++; //sumar id

    Mago mago = new Mago(id, jugador, posicionhorizontal, posicionvertical, "Mago", color);

    personajes.add(mago);
    //personajes.get(id).posicionhorizontal = 0;
    //personajes.get(id).posicionvertical = 0;
    }
    //metodo para crear un ingeniero
    //pasar id, jugador"equipo", posicion inicial
    public void crear_ingeniero(int jugador, int posicionhorizontal, int posicionvertical, Color color){
    this.id++; //sumar id

    Ingeniero ingeniero = new Ingeniero(id, jugador, posicionhorizontal, posicionvertical, "Ingeniero", color);

    personajes.add(ingeniero);
    //personajes.get(id).posicionhorizontal = 0;
    //personajes.get(id).posicionvertical = 0;
    
    }
    
    

}

