/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.juego_final2;

import com.mycompany.juego_final2.grafica.GameGridSwing;
import com.mycompany.juego_final2.grafica.Transformador;
import java.awt.Color;
import javax.swing.SwingUtilities;
/**
 *
 * @author marcr
 */
public class Menu {
    private int jugadorataque;

    public static void main(String[] args) {
         
        GameGridSwing gam = new GameGridSwing();
        //iniciar mapa
        gam.init();
        


        //crear instancia de los personajes
            //Esta lista guarda todos los personajes
            Personajes personajes = new Personajes();

        //crear jugador0
            Jugadores jugador0 = new Jugadores(0);

            personajes = jugador0.crear_personajes_iniciales(personajes);


        //crear jugador1
            Jugadores jugador1 = new Jugadores(1);
            personajes = jugador1.crear_personajes_iniciales(personajes);


        //pintar mapa inicial
            Transformador transformar = new Transformador(personajes, gam);
            transformar.pintar_posiciones_personajes();
            
        //pasar a la grafica el transformador
            gam.pasar_transformador(transformar);
            transformar.cambiar_texto_nuevo_turno();
          
    }   
    
}
