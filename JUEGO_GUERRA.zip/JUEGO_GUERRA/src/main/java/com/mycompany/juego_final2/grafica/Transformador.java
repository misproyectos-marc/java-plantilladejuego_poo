/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juego_final2.grafica;

import com.mycompany.juego_final2.Jugadores;
import com.mycompany.juego_final2.Personaje;
import com.mycompany.juego_final2.Personajes;
import java.awt.Color;
import java.util.LinkedList;

/**
 *
 * @author marcr
 */
public class Transformador {
    GameGridSwing gam;
    LinkedList<Personaje> listaPersonajes;
    Personajes personajes;
    public Transformador(Personajes personajes, GameGridSwing gam){       
        this.listaPersonajes = personajes.getPersonajes();
        this.gam = gam;
        this.personajes = personajes;
    }
    

    //pintar todo el mapa en blanco
    public void pintar_todo_blanco(int num_rows, int num_cols){
        //pintar celda por celda
       for (int row = 0; row < num_rows; row++) {
        for (int col = 0; col < num_cols; col++) {      
        gam.paintCell(row, col, Color.WHITE);
    
        }}
        }
    
    
    //pintar las posiciones de cada pieza
    public void pintar_posiciones_personajes() {
        //buscar posiciones de cada pieza
    for (Personaje personaje : listaPersonajes) {
        int horizontal = personaje.getPosicionhorizontal();
        int vertical = personaje.getPosicionvertical();
        Color color = personaje.getColor();
        //pintar coordenada
        gam.paintCell(vertical, horizontal, color);

    }
}
    
    
    
    //SOBRECARGA PASAR ID CON STRING O PASAR ID CON INT
    //pintar la longitud de ataque de la pieza seleccionada
    public void pintar_jugador_seleccionado(String valor_lista){
    //sacar id y ponerlo en variable id
        int index = valor_lista.indexOf(":") + 1;
        String idString = valor_lista.substring(index);
        int id = Integer.parseInt(idString);
    //sacar el personaje con el id por bucle
        for (Personaje personaje : listaPersonajes) {
            if (personaje.getId() == id){
            //personaje encontrado:
            //sacar horizontal, vertical, alcance
            int horizontal = personaje.getPosicionhorizontal();
            int vertical = personaje.getPosicionvertical();
            int alcance = personaje.getDistancia_ideal();
            Color color = personaje.getColor();
            //System.out.println("la distància ideal és:" + alcance + "ya que el tipo és:" + id);
            //primera cordenada = horizontal * vertical
            //horizontal + alcance
             for (int i = horizontal - alcance; i <= horizontal + alcance; i++) {
                for (int j = vertical - alcance; j <= vertical + alcance; j++) {
                    if (i >= 0 && i < 100 && j >= 0 && j < 20) {                       
                        //si la celda és blanca pintar, si no lo és no pintar
                        boolean savercol = gam.isCellColor(j, i, Color.WHITE);
                        if (savercol == true){
                        gam.paintCell(j, i, color);
                        }
                    }
                }
            }
               
            }
        }
        
        //aparte de pintar agregar el id de la pieza seleccionada en Personajes id_pieza
        personajes.setId_pieza(id);
        System.out.println(personajes.getId_pieza());
    }
    public void pintar_jugador_seleccionado(int id){
 //sacar el personaje con el id por bucle
     for (Personaje personaje : listaPersonajes) {
         if (personaje.getId() == id){
         //personaje encontrado:
         //sacar horizontal, vertical, alcance
         int horizontal = personaje.getPosicionhorizontal();
         int vertical = personaje.getPosicionvertical();
         int alcance = personaje.getDistancia_ideal();
         Color color = personaje.getColor();
         //System.out.println("la distància ideal és:" + alcance + "ya que el tipo és:" + id);
         //primera cordenada = horizontal * vertical
         //horizontal + alcance
          for (int i = horizontal - alcance; i <= horizontal + alcance; i++) {
             for (int j = vertical - alcance; j <= vertical + alcance; j++) {
                 if (i >= 0 && i < 100 && j >= 0 && j < 20) {                       
                     //si la celda és blanca pintar, si no lo és no pintar
                     boolean savercol = gam.isCellColor(j, i, Color.WHITE);
                     if (savercol == true){
                     gam.paintCell(j, i, color);
                     }
                 }
             }
         }

         }
     }

     //aparte de pintar agregar el id de la pieza seleccionada en Personajes id_pieza
     personajes.setId_pieza(id);
     System.out.println(personajes.getId_pieza());
 }
       
      

    public void mover(int tipomover){        
        int id = personajes.getId_pieza();
        System.out.println(id);
        personajes.getpersonaje(id).mover(tipomover);
        
        pintar_todo_blanco(gam.getNUM_ROWS(), gam.getNUM_COLS());
        pintar_posiciones_personajes(); 
        pintar_jugador_seleccionado(id);
        
    }
    
    public void cambiar_texto_nuevo_turno(){
    String resultado = "";  //guardar en una cadena todos los tostring del personaje 0

    for (Personaje personaje : listaPersonajes){
        if (personaje.getJugador() == 0){
            resultado += personaje.toString() + "\n";  
        }
    }
    System.out.println(resultado);
    gam.cambiartextoizquierdo(resultado);
    
    String resultado2 = "";  //guardar en una cadena todos los tostring del personaje 1

    for (Personaje personaje : listaPersonajes){
        if (personaje.getJugador() == 1){
            resultado2 += personaje.toString() + "\n";  
        }
    }
        System.out.println(resultado2);

    gam.cambiartextoderecho(resultado2);
    
    }

    
    }

